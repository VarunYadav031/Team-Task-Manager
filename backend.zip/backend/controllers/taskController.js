import Task from "../models/Task.js";

// CREATE TASK (Admin)
export const createTask = async (req, res) => {
  try {
    const { title, description, assignedTo, project, dueDate } = req.body;

    const task = await Task.create({
      title,
      description,
      assignedTo,
      project,
      dueDate,
      createdBy: req.user._id,
    });

    res.status(201).json(task);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET TASKS
export const getTasks = async (req, res) => {
  try {
    let tasks;

    if (req.user.role === "admin") {
      tasks = await Task.find()
        .populate("assignedTo", "name email")
        .populate("project", "name");
    } else {
      tasks = await Task.find({ assignedTo: req.user._id });
    }

    res.json(tasks);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// UPDATE TASK
export const updateTask = async (req, res) => {
  try {
    const { progress, status } = req.body;

    const task = await Task.findById(req.params.id);

    if (!task) return res.status(404).json({ message: "Task not found" });

    // permission
    if (
      task.assignedTo.toString() !== req.user._id.toString() &&
      req.user.role !== "admin"
    ) {
      return res.status(403).json({ message: "Not allowed" });
    }

    task.progress = progress ?? task.progress;

    if (task.progress === 100) {
      task.status = "done";
    } else if (task.progress > 0) {
      task.status = "in-progress";
    }

    if (status) task.status = status;

    // Activity log
    task.activityLog.push({
      user: req.user._id,
      action: `Updated to ${task.status} (${task.progress}%)`,
    });

    await task.save();

    res.json(task);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE TASK
export const deleteTask = async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
};