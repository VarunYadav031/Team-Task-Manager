import express from "express";
import { getUsers } from "../controllers/userController.js";
import { protect, isAdmin } from "../middleware/authMiddleware.js";

const router = express.Router();

// Admin only
router.get("/", protect, isAdmin, getUsers);

export default router;