import express from "express";
import {
  createTask,
  getTasks,
  
  updateTask,
} from "../controllers/taskController.js";

import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/", createTask);
router.get("/:projectId", getTasks);

router.put("/:id", updateTask);

export default router;